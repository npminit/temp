
exports.run = (client, message, args) => {
  

  notify(args.join(' '), 'all');
}
