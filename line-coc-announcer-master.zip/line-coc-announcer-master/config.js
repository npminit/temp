module.exports = {
  line: {
    channelAccessToken: "iNU2o9eniAHInktzjFYPQFjDV2Tx8+Z5kOVFHDjaR0ORI1mN4O3VZsdjmMv4hzxiFyaoW5oYVkFNTCps0qQpJjPtitnMca+UPMu5KGavyM+8+vYOvjjRvXxVSo8LTYYwnOS0tiDcYCeIbc6R9U6kkQdB04t89/1O/w1cDnyilFU=",
    channelSecret: "2275fd919dff9abf562545cca8cf0989",
    port: "8080"
  },
  updateInterval: 60 * 10, // 10 Minutes
  cocApiKey: "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6ImNhOGZjNDlmLWEzMWItNDZiNy05ZTczLTY2ZGI1NWRiYTk1ZCIsImlhdCI6MTUwODA4Mjk2Mywic3ViIjoiZGV2ZWxvcGVyLzIxMzY3ZWE1LTE0NDctZTk0Zi0zYzExLTFmOWY4YzViMmU5YyIsInNjb3BlcyI6WyJjbGFzaCJdLCJsaW1pdHMiOlt7InRpZXIiOiJkZXZlbG9wZXIvc2lsdmVyIiwidHlwZSI6InRocm90dGxpbmcifSx7ImNpZHJzIjpbIjM1LjE5OC4yMjMuOTUiXSwidHlwZSI6ImNsaWVudCJ9XX0.3hZXFKxzRwteUYmjeFf7GMEqVlt3UggFfKZXNqCLGE-2KVzdECiUdpDvmNkr6KoHYfpjQ-mli6_SvSMCga_38Q",
  finalMinutes: 15,
  messages: {
    prepDay: {
      title: 'War has been declared',
      body: 'The battle begins %date%\n@ %time%'
    },
    clanCastleReminder: {
      title: 'Battle day is going to start in 2 hours',
      body: 'Don\'t forget to fill Clan Castle Reinforcments'
    },
    battleDay: {
      title: 'Battle day has begun!',
      body: 'Good Luck with your Attacks!\nLet\'s win this'
    },
    lastHour: {
      title: 'The final hour is upon us!',
      body: 'If you haven\'t made both of your attacks you better get on it.'
    },
    finalMinutes: {
      title: 'The final minutes are here!',
      body: 'If you haven\'t made both of your attacks you better get on it.'
    }
  }
}
