
module.exports = (attackData, warData) => {
  /* add your code here if you want to add anything extra */
}