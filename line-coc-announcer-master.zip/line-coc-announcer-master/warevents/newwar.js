
module.exports = (warData) => {
  /* add your code here if you want to add anything extra */
}