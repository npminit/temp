
exports.run = (client, message, args) => {
	var clanTag = checkClan(message.group.id);
	if (!clanTag) return message.reply("No clan claimed in this group.\n'claim #clanTag'");
   var warData = Storage.getItemSync(clanData[clanTag].warId);
   if (!warData) return message.reply("No War Data found\nPossible reasons:1.Clan is not in war.\n2.WarLog private for to long(Public it and type 'refresh')3.API is down.")
  var number = args[0];

  var user = args[1];

  var clanTag = checkClan(message.group.id);

  var warCalls = Storage.getItemSync(`${clanData[clanTag].warId}warCalls`);

  if (warData.stats.state == "warEnded") return message.reply("There is no war to be cancelling calls");

  if (number < 1 || number > warData.stats.opponent.memberCount) {
    return message.reply(`Bases are only between 1 and ${warData.stats.opponent.memberCount}`);
  }
  Head = `${warData.stats.clan.name} vs ${warData.stats.opponent.name}\n\n    Stars: ${warData.stats.clan.stars} vs ${warData.stats.opponent.stars}\n\n`
  var call = warCalls[number].split('//')

  if(call[0] === "empty" ){
    message.reply(`That spot isn't called yet`);
  } else if (call[0] === "hide") {
    message.reply(`${number} is 3 Starred`)
  } else if (call[1] !== message.author.id) {
	  var callername = call[0]
	warCalls[number] = "empty";
    Storage.setItemSync(`${clanData[clanTag].warId}warCalls`, warCalls);
	list(message.group.id, (list) => {
      message.reply(`${Head}${message.author.username} has overwritten ${callername}\'s call*\n\n${list}\nUse list appropriately`);
    })
  } else {
    warCalls[number] = "empty";
    clanData[clanTag].userData[message.author.id].calls -= 1;
    Storage.setItemSync(`${clanData[clanTag].warId}warCalls`, warCalls);

    list(message.group.id, (list) => {
      message.reply(`${Head}${number} has been canceled\n\n${list}\nUse list appropriately`);
    })
  }
}

exports.description = "cancel your call `cancel 4`";
