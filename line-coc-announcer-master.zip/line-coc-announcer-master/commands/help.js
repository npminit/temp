

exports.run = (client, message, args) => {
	var helpmessage = `Add me as your Friend\n\nCommands:\n\n1.Enables war updates for a group 'claim #ClanTag'\n
2.Displays base calling list 'bases'
3.Is used for base calling 'Call 7/Call 7 Mini'
4.Displays the list of commands 'help'
5.Check current war hitrate stats 'hitrate'
6.Gets user IDs 'id' [Not for users]
7.Check what bases aren't called 'open'
8.Check bot's response time 'Ping' [Not for users]
9.Check player's profile 'playerstats #playertag'
10.Report issues with the bot 'Report the help command isn't working'
11.Request troops 'request bowlers' or for mini accounts 'request bowlers accountname'[Not working]
12.Subscribe to some war events 'subscribe'
13.Suggest improvements to the bot 'suggest this would be a cool command'
14.Is used for cancelling calls 'uncall'
15.Stop recieving war updates and troops request from users 'unsubscribe'
16. Check war stats of war 'warstats'
17. Refresh data from the API 'refresh'
Thanks for Choosing me`
message.reply(helpmessage);
}

exports.description = "shows the list of commands `help`";
