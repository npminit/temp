exports.run = (client, message, args) => {

  var clanTag = checkClan(message.group.id);
	if (!clanTag) return message.reply("No clan claimed in this group.\n'claim #clanTag'");
	 var warData = Storage.getItemSync(clanData[clanTag].warId);
   if (!warData) return message.reply("No War Data found\nPossible reasons:1.Clan is not in war.\n2.WarLog private for to long(Public it and type 'refresh')3.API is down.")
  var warCalls = Storage.getItemSync(`${clanData[clanTag].warId}warCalls`);

  let number = args[0]

  let userArgs = args.map((arg, index) => {
    if (index != 0) return arg
  });
  
  let user = userArgs.join(" ");

  if (warData.stats.state == "warEnded") return message.reply("There is no war to be calling oponents");

  if (number < 1 || number > warData.stats.opponent.memberCount) {
    return message.reply(`Opponents bases are only between 1 and ${warData.stats.opponent.memberCount}`);
  }
  Head = `${warData.stats.clan.name} vs ${warData.stats.opponent.name}\n\n    Stars: ${warData.stats.clan.stars} vs ${warData.stats.opponent.stars}\n\n`
  var call = warCalls[number].split('//')
  if (call[0] == 'hide') return message.reply(`${number} is 3 Starred`)
if (call[1] == message.author.id) return message.reply(`You have already called ${number}`)
    if (call[1] != message.author.id && call[0] != "empty") {
    message.reply(`${number} is taken by ${call[0]}`);
  }
  if(call[0] === "empty") {
    if (!clanData[clanTag].userData) clanData[clanTag].userData = {};
    if (!clanData[clanTag].userData[message.author.id]) {
      clanData[clanTag].userData[message.author.id] = {calls:0}
    }
    if (clanData[clanTag].userData[message.author.id].calls >=1000) {
      message.reply("You have already called two opponent bases uncall one before calling another");
    } else if (user) {
      warCalls[number] = `${user}//${message.author.id}//${new Date().getTime()}`;
      Storage.setItemSync(`${clanData[clanTag].warId}warCalls`, warCalls);
      clanData[clanTag].userData[message.author.id].calls++

      list(clanTag, (list) => {
	  message.reply(`${Head}${message.author.username} has called ${number} for ${user}\n\n${list}\nUse list appropriately`);
      })
        
    } else {
      
      warCalls[number] = `${message.author.username}//${message.author.id}//${new Date().getTime()}`;
      Storage.setItemSync(`${clanData[clanTag].warId}warCalls`, warCalls);
      clanData[clanTag].userData[message.author.id].calls++

      list(clanTag, (list) => {
        message.reply(`${Head}${message.author.username} has called ${number}\n\n${list}\nUse list appropriately`);
      })
      
    }

  } else if (call[1] !== message.author.id) {
    message.reply(`${number} is taken by ${call[0]}`);
  }
}