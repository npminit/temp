const moment = require('moment');
exports.run = (client, message, args) => {
	var clanTag = checkClan(message.group.id);
	if (!clanTag) return message.reply("No clan claimed in this group.\n'claim #clanTag'");
   var warData = Storage.getItemSync(clanData[clanTag].warId);
   if (!warData) return message.reply("No War Data found\nPossible reasons:1.Clan is not in war.\n2.WarLog private for to long(Public it and type 'refresh')3.API is down.")
  list(message.group.id, (list) => {
var warT = '';
        if (warData.stats.state === 'preparation') {
          warT = 'War starts ' + moment(warData.stats.startTime).fromNow()
        } else if (warData.stats.state === 'inWar') {
          warT = 'War ends ' + moment(warData.stats.endTime).fromNow()
        } else if (warData.stats.state === 'warEnded') {
        warT = 'War ended ' + moment(warData.stats.endTime).fromNow()
        }
        var Head = `${warData.stats.clan.name} vs ${warData.stats.opponent.name}\n\n            Stars: ${warData.stats.clan.stars} vs ${warData.stats.opponent.stars}\n   Percentage: ${warData.stats.clan.destructionPercentage.toFixed(2)}% vs ${warData.stats.opponent.destructionPercentage.toFixed(2)}%\n  Timer: ${warT}\n            Attacks: ${warData.stats.clan.attacks} vs ${warData.stats.opponent.attacks}\n            3 Stars: ${warData.stats.clan.threeStars} vs ${warData.stats.opponent.threeStars}          \n            War Size: ${warData.stats.clan.memberCount} vs ${warData.stats.opponent.memberCount}`;
      
    message.reply(`${Head}\n\n${list}\nUse list appropriately`);
  })

}
