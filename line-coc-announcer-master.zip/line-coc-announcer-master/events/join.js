
exports.run = (client, group) => {
  var JoinMessage = `Hello I'm here to help you with your clan wars.\n\nAdd me as your friend.\n'Help' shows all my commands.\nStart by claiming a clan 'claim clanTag'\n\n(Feel free to report bugs and suggest new features)`

  group.sendMessage(JoinMessage);
}